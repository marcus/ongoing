# @impressions/logo

Portable, versioned Impressions logo documents and the framework-neutral point viewer. Build and pack with `npm run logo:pack`; the resulting tarball has no source-path dependency on the Impressions repository.

The frozen point snapshot is the display authority. The recipe remains available for reopening and explicit regeneration.
